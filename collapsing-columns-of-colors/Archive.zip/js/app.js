$(window).bind('load', function () {

    // shim layer with setTimeout fallback
    window.requestAnimFrame = (function () {
        return window.requestAnimationFrame ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame ||
            function (callback) {
                window.setTimeout(callback, 1000 / 60);
            };
    })();

    const raf = function (entry) {
        window.requestAnimFrame(entry);
    };
    const caf = function (entry) {
        window.cancelAnimationFrame(entry);
    };
    const random = function (min, max) {
        max = max + 1;
        return Math.floor(Math.random() * (max - min) + min);
    }
    const min = function (arr) {
        return Math.min.apply(Math, arr); // 3
    }
    const max = function (arr) {
        return Math.max.apply(Math, arr); // 3
    }
    var bodyHTML = $('body, html'),
        container = $('#container'),
        sceneContainer = $('#scene-container'),
        c = document.getElementById('c'),
        cx = c.getContext('2d'),
        cbg = {
            rgb: '255,255,255',
            a: 1
        },
        camY = 0,
        test = $('#test'),
        Particle,
        particles = {},
        particleNum = 1,
        particleIndex = 0,
        mouseX = null,
        mouseY = null,
        particlesRendered = false;

    TweenMax.set(bodyHTML, {
        backgroundColor: 'white'
    });

    TweenMax.set(container, {
        opacity: 1,
        backgroundColor: 'white'
    });

    TweenMax.set(sceneContainer, {
        opacity: 1,
        backgroundColor: 'white'
    });

    c.width = $('#c').outerWidth();
    c.height = $('#c').outerHeight();

    var w = c.width,
        h = c.height;

    cx.fillStyle = `rgba(${cbg.rgb},${cbg.a})`;
    cx.fillRect(0, 0, w, h);

    Particle = function () {
        this.w;
        this.h;
        this.x;
        this.y;
        this.hue;
        this.saturation;
        this.light;
        this.opacity;
        particles[particleIndex] = this;
        this.id = particleIndex;
        particleIndex++;
    }

    Particle.prototype.draw = function () {

        cx.fillStyle = `hsla(${this.hue},${this.saturation}%,${this.light}%,${this.opacity})`;
        cx.fillRect(this.x, this.y, this.w, this.h);
    }

    function render() {
        $(window).resize(function () {
            c.width = $('#c').outerWidth();
            c.height = $('#c').outerHeight();
            w = c.width;
            h = c.height;
        });
        cx.globalCompositeOperation = 'source-over';
        cx.fillStyle = `rgba(${cbg.rgb},${cbg.a})`;
        cx.fillRect(0, 0, w, h);
        if (!particlesRendered) {
            particlesRendered = true;
            for (var i = 0; i < particleNum; i++) {
                new Particle();
            }
        }

        cx.globalCompositeOperation = 'lighter';

        for (var i in particles) {
            particles[i].draw();
        }

        raf(render);
    }

    raf(render);

    window.addEventListener('mousemove', mouseCoord, false);

    function mouseCoord(e) {
        mouseX = e.clientX;
        mouseY = e.clientY;
    }

    var camPosY = -300,
        newCamPosY = 0,
        camPosZ = 400,
        newCamPosZ = 0,
        camRotX = 0.70,
        newCamRotX = 0,
        camRotY = 0,
        newCamRotY = 0,
        camRotZ = 0,
        newCamRotZ = 0,
        cubeWidthInit = 100,
        cubeWidth = cubeWidthInit,
        newCubeWidth = 0,
        cubeHeightInit = 100,
        cubeHeight = cubeHeightInit,
        newCubeHeight = 0,
        cubeLengthInit = 300,
        cubeLength = cubeLengthInit,
        newCubeLength = 0,
        cubeMult = -1,
        cubePosY = 0,
        cube2PosY = 0;

    test.html('hey');

    var renderer = new THREE.WebGLRenderer();

    function createScene() {
        renderer.setSize(window.innerWidth, window.innerHeight);

        var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 1000);

        camera.position.y = camPosY + newCamPosY;
        camera.position.z = camPosZ + newCamPosZ;
        camera.rotation.x = camRotX + newCamRotX;
        camera.rotation.y = camRotY + newCamRotY;
        camera.rotation.z = camRotZ + newCamRotZ;

        var scene = new THREE.Scene();

        renderer.setClearColor(0xffffff); // white background - replace ffffff with any hex color

        //        var plane = new THREE.Mesh(new THREE.PlaneGeometry(300, 300), new THREE.MeshNormalMaterial());

        var cube = new THREE.Mesh(new THREE.CubeGeometry(cubeWidth, cubeHeight, cubeLength), new THREE.MeshNormalMaterial());
        var cube2 = new THREE.Mesh(new THREE.CubeGeometry(cubeWidth, cubeHeight, cubeLength), new THREE.MeshNormalMaterial());
        var plane = new THREE.Mesh(new THREE.PlaneGeometry(500, 500), new THREE.MeshNormalMaterial());

        cube.rotation.z = .75;
        cube2.position.x = 0;
//        cubePosY = 0 + cubeLength / 2;
//        cube2PosY = 0 + cubeLength / 2;
        cube.position.y = cubePosY;
        cube2.position.y = cube2PosY;

//        scene.add(plane);
        scene.add(cube);
        scene.add(cube2);
        renderer.render(scene, camera);
    }

    function rafEvents() {
//        newCamPosY++;
//        newCamPosZ+=5;
//        newCamRotZ+=0.01;
//        cubePosY = 0 + cubeLength / 2;
        cubeLength+=newCubeLength;
        if (cubeLength < 1) {
            console.log('ya');
            newCubeLength *= -1;
            cubeMult *= 1.5;
            cubeLength = 1;
        }
        newCubeLength+=cubeMult;
//        if (cubeLength > cubeLengthInit) {
//            newCubeLength *= -1;
//            cubeLength = cubeLengthInit;
//        }
        renderer.setSize(window.innerWidth, window.innerHeight);
        sceneContainer.empty();
        sceneContainer.html(renderer.domElement);
        createScene();
        //        camPosZ++;
        //        camPosZ+=5;
        raf(rafEvents);

    }

    raf(rafEvents);
});